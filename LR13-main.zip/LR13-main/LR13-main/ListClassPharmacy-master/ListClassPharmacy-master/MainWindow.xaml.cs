﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ListClass.Classes;

namespace ListClass
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly object DtgListThing;

        // List<Thing>  = new List<Thing>();
        public MainWindow()
        {
            InitializeComponent();
            ConnectHelper.thing.Add(new Pharmacy("Цитрамон", 100, 199.90, 36));
            ConnectHelper.thing.Add(new Pharmacy("Парацетамол", 200, 279.90, 24));
            ConnectHelper.thinh.Add(new Pharmacy("Нурофен", 255, 356.90, 24));
            ConnectHelper.thing.Add(new Pharmacy("Спазган", 99, 555.01, 36));
            ConnectHelper.pharmacies.Add(new Pharmacy("Витамин C", 1000, 50.00, 12));
            ConnectHelper.pharmacies.Add(new Pharmacy("Зодак", 5, 356.90, 24));
            ConnectHelper.pharmacies.Add(new Pharmacy("Ибупрофен", 35, 555.01, 36));
            ConnectHelper.pharmacies.Add(new Pharmacy("Пенталгин", 8, 50.00, 12));

            DtgListThing.ItemsSource = ConnectHelper.pharmacies;
            //pharmacies.Add(new Pharmacy("Цитрамон", 100, 199.90, 36));
            //pharmacies.Add(new Pharmacy("Парацетамол", 200, 279.90, 24));
            //pharmacies.Add(new Pharmacy("Нурофен", 255, 356.90, 24));
            //pharmacies.Add(new Pharmacy("Спазган", 99, 555.01, 36));
            //pharmacies.Add(new Pharmacy("Витамин C", 1000, 50.00, 12));
            //pharmacies.Add(new Pharmacy("Зодак", 5, 356.90, 24));
            //pharmacies.Add(new Pharmacy("Ибупрофен", 35, 555.01, 36));
            //pharmacies.Add(new Pharmacy("Пенталгин", 8, 50.00, 12));
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            DtgListThing.ItemsSource = ConnectHelper.thing.ToList();
            DtgListThing.SelectedIndex = -1;
           
        }
        /// <summary>
        /// сортировка по алфавиту
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgListThing.ItemsSource = ConnectHelper.thing.OrderBy(x=>x.NameThing).ToList();
        }
        /// <summary>
        /// сортировка в обратном порядке
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgListPreparate.ItemsSource = ConnectHelper.pharmacies.OrderByDescending(x => x.NamePreparate).ToList();
        }
        /// <summary>
        /// поиск по названию
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgListPreparate.ItemsSource = ConnectHelper.pharmacies.Where(x => 
                x.NamePreparate.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

       /// <summary>
       /// фильтр по количеству
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            if (CmbFiltr.SelectedIndex == 0)
            {
                DtgListThing.ItemsSource = ConnectHelper.things.Where(x =>
                    x.CountThing >=0 && x.CountThing <= 10).ToList();
                MessageBox.Show("Этого предмета нет в списке!",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
                if (CmbFiltr.SelectedIndex == 1)
            {
                DtgListThing.ItemsSource = ConnectHelper.things.Where(x =>
                    x.CountThing >= 11 && x.CountThing <= 50).ToList();
                MessageBox.Show("Необходимо пополнить список предметов",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                DtgListThing.ItemsSource = ConnectHelper.pharmacies.Where(x =>
                   x.CountThing >= 51).ToList();
                MessageBox.Show("Достаточное количество предметов!",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowAddThing windowAdd = new WindowAddThing();
            windowAdd.ShowDialog();
        }

       

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            DtgListThing.ItemsSource = null;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

      
    }
}
